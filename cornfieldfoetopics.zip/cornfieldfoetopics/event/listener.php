<?php
/**
*
* @package phpBB Extension - Hide foe topics entirely
* @copyright (c) 2016 James Dominic - http://www.skepticalcommunity.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jdominic\cornfieldfoetopics\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
* Event listener
*/
class listener implements EventSubscriberInterface
{
	
	/** @var \phpbb\request\request */
	protected $request;

	/** @var \phpbb\template\template */
	protected $template;

	/** @var \phpbb\user */
	protected $user;

	/** @var \phpbb\db\driver\driver */
	protected $db;

	/** @var \phpbb\config\config */
	protected $config;

	/**
	* Constructor
	*
	* @param \phpbb\request\request				$request
	* @param \phpbb\template\template			$template
	* @param \phpbb\user						$user
	* @param \phpbb\db\driver\driver			$db
	* @param \phpbb\config\config				$config
	*/
	public function __construct(\phpbb\request\request $request, \phpbb\template\template $template, \phpbb\user $user, \phpbb\db\driver\driver_interface $db, \phpbb\config\config $config)
	{
		$this->request = $request;
		$this->template = $template;
		$this->user = $user;
		$this->auth = $auth;
		$this->db = $db;
		$this->config = $config;
	}

    static public function getSubscribedEvents()
    {
        return array(
			'core.user_setup'                   => 'load_user_data',
			'core.ucp_prefs_view_data'          => 'ucp_prefs_get_data',
			'core.ucp_prefs_view_update_data'   => 'ucp_prefs_set_data',
			'core.viewforum_get_topic_data'	    => 'get_topicauthor_data',
			'core.viewforum_modify_topic_row'    => 'modify_topicrow_options',
        );
    }

	/**
	* Load the necessary data during user setup
	*
	* @param object $event The event object
	* @return null
	* @access public
	*/
	public function load_user_data($event)
	{
		// Load the language file
		$lang_set_ext	= $event['lang_set_ext'];
		$lang_set_ext[]	= array(
			'ext_name' => 'pyrrho/cornfieldfoetopics',
			'lang_set' => 'cornfieldtopics',
		);
		$event['lang_set_ext'] = $lang_set_ext;
	}	
	
	/**
	 * Add user's option state into the sql_array
	 *
	 * @param object $event The event object
	 * @return void
	 */
	public function ucp_prefs_set_data($event)
	{
		$data = $event['data'];
		$event['sql_ary'] = array_merge($event['sql_ary'], array(
			'cornfieldfoetopics' => $data['cornfieldfoetopics'],
		));
	}
	
	/**
	 * Get user's option and display it in UCP Prefs View page
	 *
	 * @param object $event The event object
	 * @return void
	 */
	public function ucp_prefs_get_data($event)
	{
		// Request the user option vars and add them to the data array
		$event['data'] = array_merge($event['data'], array(
			'cornfieldfoetopics'	=> $this->request->variable('cornfieldfoetopics', (bool) $this->user->data['cornfieldfoetopics']),
		));
		// Output the data vars to the template (except on form submit)
		if (!$event['submit'])
		{
			$data = $event['data'];
			//$this->user->add_lang_ext('pyrrho/cornfieldfoetopics', 'cornfieldfoetopics');
			$this->template->assign_vars(array(
				'S_CORNFIELDFOETOPICS'	=> $data['cornfieldfoetopics'],
			));
		}
	}
	
	public function get_topicauthor_data($event)
	{
		// Request the zebra data for the topic author
		$event['data'] = 
		$sql = $db->sql_build_query('SELECT', array(
	'SELECT'	=> 'u.*, z.friend, z.foe, p.*',

	'FROM'		=> array(
		USERS_TABLE		=> 'u',
		TOPICS_TABLE		=> 't',
	),

	'LEFT_JOIN'	=> array(
		array(
			'FROM'	=> array(ZEBRA_TABLE => 'z'),
			'ON'	=> 'z.user_id = ' . $user->data['user_id'] . ' AND z.zebra_id = t.topic_poster'
		)
	),

	'WHERE'		=> $db->sql_in_set('t.topic_id', $topic_list) . '
		AND u.user_id = t.topic_poster'
	));,
	);
		// Output the data to the template
		if (!$event['submit'])
		{
			$data = $event['data'];
			$this->template->assign_vars(array(
				'S_AUTHOR_IS_FOE'	=> $data['cornfieldfoetopics'],
			));
		}
		
	}
	
	public function modify_topicrow_options($event)
	{	
		// Request the user option vars and add them to the data array
		$event['data'] = array('cornfieldfoetopics'	=> $this->request->variable('cornfieldfoetopics', (bool) $this->user->data['cornfieldfoetopics']),
		);
		// Output the data vars to the template (except on form submit)
		if (!$event['submit'])
		{
			$data = $event['data'];
			$this->template->assign_vars(array(
				'S_CORNFIELDFOETOPICS'	=> $data['cornfieldfoetopics'],
			));
		}
	}
}

/* Pseudocode
Get the topic author ID from the TOPICS_TABLE ...this will be the "topic_poster" value
Compare with values in the ZEBRA_TABLE
select from zebra table where u = user_id and topic_poster = zebra.id and "foe" = 1

// Will have to review this thoroughly, look at viewtopic and viewforum

<?php
$sql = $db->sql_build_query('SELECT', array(
	'SELECT'	=> 'u.*, z.friend, z.foe, p.*',

	'FROM'		=> array(
		USERS_TABLE		=> 'u',
		TOPICS_TABLE		=> 't',
	),

	'LEFT_JOIN'	=> array(
		array(
			'FROM'	=> array(ZEBRA_TABLE => 'z'),
			'ON'	=> 'z.user_id = ' . $user->data['user_id'] . ' AND z.zebra_id = t.topic_poster'
		)
	),

	'WHERE'		=> $db->sql_in_set('t.topic_id', $topic_list) . '
		AND u.user_id = t.topic_poster'
));
?>


*/
