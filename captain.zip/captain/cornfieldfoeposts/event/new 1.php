	/** @var \phpbb\request\request */
	protected $request;

	/** @var \phpbb\template\template */
	protected $template;

	/** @var \phpbb\user */
	protected $user;

	/** @var \phpbb\db\driver\driver */
	protected $db;

	/** @var \phpbb\config\config */
	protected $config;

	/**
	* Constructor
	*
	* @param \phpbb\request\request				$request
	* @param \phpbb\template\template			$template
	* @param \phpbb\user						$user
	* @param \phpbb\db\driver\driver			$db
	* @param \phpbb\config\config				$config
	*/
	public function __construct(\phpbb\request\request $request, \phpbb\template\template $template, \phpbb\user $user, \phpbb\db\driver\driver_interface $db, \phpbb\config\config $config)
	{
		$this->request = $request;
		$this->template = $template;
		$this->user = $user;
		$this->auth = $auth;
		$this->db = $db;
		$this->config = $config;
	}

	/**
	* Assign functions defined in this class to event listeners in the core
	*
	* @return array
	* @static
	* @access public
	*/
	static public function getSubscribedEvents()
	{
		return array(
			'core.ucp_prefs_post_data'		=> 'modify_display_options',
			'core.ucp_prefs_view_update_data'		=> 'display_options_sql_ary',
			'core.page_header'		=> 'generate_template_vars',
		);
	}

	/**
	* Allows user to send foe posts to the Cornfield
	*
	* @param object $event The event object
	* @return null
	* @access public
	*/
	public function modify_display_options($event)
	{
		$this->user->add_lang_ext('captain/cornfieldfoeposts', 'cornfield');

		// Request the user option vars and add them to the data array
		$event['data'] = array_merge($event['data'], array(
			'user_cornfieldfoeposts'	=> $this->request->variable('user_cornfieldfoeposts', $this->user->data['user_cornfieldfoeposts'], true),
		));

		$this->template->assign_vars(array(
			'CORNFIELDFOEPOSTS'		=> $event['data']['user_cornfieldfoeposts'],
		));
	}

	/**
	* Changed their options, update the database
	*
	* @param object $event The event object
	* @return null
	* @access public
	*/
	public function display_options_sql_ary($event)
	{
		// User has changed their display choices, update the user table
		$this->update_users_table($event['data']['user_cornfieldfoeposts']);

		$event['sql_ary'] = array_merge($event['sql_ary'], array(
			'user_cornfieldfoeposts' => $event['data']['user_cornfieldfoeposts'],
		));
	}
	
	/**
	* Assign template vars
	*
	* @param object $event The event object
	* @return null
	* @access public
	*/
	public function generate_template_vars($event)
	{
		$s_cornfieldfoeposts = ($user->data['user_cornfieldfoeposts'] == 1) ? 1 : 0;
		$template->assign_var('S_CORNFIELDFOEPOSTS', $s_cornfieldfoeposts); 
	}

	/**
	* Update user choices
	* @param object $user_cornfieldfoeposts -- not sure this is needed...we will need to know the BOOL value and set the postrow to invisible somehow. None of this looks valid for what we're doing.
	* @return null
	* @access private
	*/
	
	private function update_users_table($user_user_cornfieldfoeposts)
	{
		$sql_ary = array(
			'topic_last_poster_colour'	=> $user_cornfieldfoeposts,
		);
		$sql = 'UPDATE ' . USERS_TABLE . ' SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . ' WHERE user_id = ' . $this->user->data['user_id'];
		$this->db->sql_query($sql);


		return;
	}